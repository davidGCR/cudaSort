Sample: volumeRender
Minimum spec: SM 3.0

This sample demonstrates basic volume rendering using 3D Textures.

Key concepts:
Graphics Interop
Image Processing
3D Textures
