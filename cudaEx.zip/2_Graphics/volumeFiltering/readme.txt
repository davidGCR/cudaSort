Sample: volumeFiltering
Minimum spec: SM 3.0

This sample demonstrates 3D Volumetric Filtering using 3D Textures and 3D Surface Writes.

Key concepts:
Graphics Interop
Image Processing
3D Textures
Surface Writes
