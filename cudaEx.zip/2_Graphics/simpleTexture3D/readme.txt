Sample: simpleTexture3D
Minimum spec: SM 3.0

Simple example that demonstrates use of 3D Textures in CUDA.

Key concepts:
Graphics Interop
Image Processing
3D Textures
Surface Writes
