Sample: BlackScholes_nvrtc
Minimum spec: SM 3.0

This sample evaluates fair call and put prices for a given set of European options by Black-Scholes formula, compiling the CUDA kernels involved at runtime using NVRTC.
    

Key concepts:
Computational Finance
Runtime Compilation
