Sample: binomialOptions_nvrtc
Minimum spec: SM 3.0

This sample evaluates fair call price for a given set of European options under binomial model. This sample makes use of NVRTC for Runtime Compilation.

Key concepts:
Computational Finance
Runtime Compilation
