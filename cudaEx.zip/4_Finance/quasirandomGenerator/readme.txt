Sample: quasirandomGenerator
Minimum spec: SM 3.0

This sample implements Niederreiter Quasirandom Sequence Generator and Inverse Cumulative Normal Distribution functions for the generation of Standard Normal Distributions.

Key concepts:
Computational Finance
