Sample: deviceQueryDrv
Minimum spec: SM 3.0

This sample enumerates the properties of the CUDA devices present using CUDA Driver API calls

Key concepts:
CUDA Driver API
Device Query
