Sample: topologyQuery
Minimum spec: SM 3.0

A simple exemple on how to query the topology of a system with multiple GPU

Key concepts:
Performance Strategies
Multi-GPU
