Sample: p2pBandwidthLatencyTest
Minimum spec: SM 3.0

This application demonstrates the CUDA Peer-To-Peer (P2P) data transfers between pairs of GPUs and computes latency and bandwidth.  Tests on GPU pairs using P2P and without P2P are tested.

Key concepts:
Performance Strategies
Asynchronous Data Transfers
Unified Virtual Address Space
Peer to Peer Data Transfers
Multi-GPU
