Sample: systemWideAtomics
Minimum spec: SM 6.0

A simple demonstration of system wide atomic instructions.

Key concepts:
Atomic Intrinsics
Unified Memory
