Sample: fp16ScalarProduct
Minimum spec: SM 5.3

Calculates scalar product of two vectors of FP16 numbers.

Key concepts:
CUDA Runtime API
