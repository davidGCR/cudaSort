Sample: simpleCubemapTexture
Minimum spec: SM 3.0

Simple example that demonstrates how to use a new CUDA 4.1 feature to support cubemap Textures in CUDA C.

Key concepts:
Texture
Volume Processing
