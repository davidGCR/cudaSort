Sample: simpleCooperativeGroups
Minimum spec: SM 3.0

This sample is a simple code that illustrates basic usage of cooperative groups within the thread block.

Key concepts:
Cooperative Groups
