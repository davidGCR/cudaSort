Sample: simpleCallback
Minimum spec: SM 3.0

This sample implements multi-threaded heterogeneous computing workloads with the new CPU callbacks for CUDA streams and events introduced with CUDA 5.0.

Key concepts:
CUDA Streams
Callback Functions
Multithreading
