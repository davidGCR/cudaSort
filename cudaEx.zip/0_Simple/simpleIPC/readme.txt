Sample: simpleIPC
Minimum spec: SM 3.0

This CUDA Runtime API sample is a very basic sample that demonstrates Inter Process Communication with one process per GPU for computation.  Requires Compute Capability 2.0 or higher and a Linux Operating System

Key concepts:
CUDA Systems Integration
Peer to Peer
InterProcess Communication
