Sample: vectorAdd
Minimum spec: SM 3.0

This CUDA Runtime API sample is a very basic sample that implements element by element vector addition. It is the same as the sample illustrating Chapter 3 of the programming guide with some additions like error checking.

Key concepts:
CUDA Runtime API
Vector Addition
