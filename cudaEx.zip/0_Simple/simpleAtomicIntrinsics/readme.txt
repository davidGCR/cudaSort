Sample: simpleAtomicIntrinsics
Minimum spec: SM 3.0

A simple demonstration of global memory atomic instructions. Requires Compute Capability 2.0 or higher.

Key concepts:
Atomic Intrinsics
