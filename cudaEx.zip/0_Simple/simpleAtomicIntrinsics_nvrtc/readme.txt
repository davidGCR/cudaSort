Sample: simpleAtomicIntrinsics_nvrtc
Minimum spec: SM 3.0

A simple demonstration of global memory atomic instructions.This sample makes use of NVRTC for Runtime Compilation.

Key concepts:
Atomic Intrinsics
Runtime Compilation
