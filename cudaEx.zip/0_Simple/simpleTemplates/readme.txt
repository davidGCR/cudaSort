Sample: simpleTemplates
Minimum spec: SM 3.0

This sample is a templatized version of the template project. It also shows how to correctly templatize dynamically allocated shared memory arrays.

Key concepts:
C++ Templates
