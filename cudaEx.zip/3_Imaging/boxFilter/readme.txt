Sample: boxFilter
Minimum spec: SM 3.0

Fast image box filter using CUDA with OpenGL rendering.

Key concepts:
Graphics Interop
Image Processing
