Sample: convolutionTexture
Minimum spec: SM 3.0

Texture-based implementation of a separable 2D convolution with a gaussian kernel. Used for performance comparison against convolutionSeparable.

Key concepts:
Image Processing
Texture
Data Parallel Algorithms
