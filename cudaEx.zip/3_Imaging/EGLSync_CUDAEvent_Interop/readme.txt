Sample: EGLSync_CUDAEvent_Interop
Minimum spec: SM 3.0

Demonstrates interoperability between CUDA Event and EGL Sync/EGL Image using which one can achieve synchronization on GPU itself for GL-EGL-CUDA operations instead of blocking CPU for synchronization.

Key concepts:
EGLSync-CUDAEvent Interop
EGLImage-CUDA Interop
