Sample: simpleCUDA2GL
Minimum spec: SM 3.0

This sample shows how to copy CUDA image back to OpenGL using the most efficient methods.

Key concepts:
Graphics Interop
Image Processing
Performance Strategies
