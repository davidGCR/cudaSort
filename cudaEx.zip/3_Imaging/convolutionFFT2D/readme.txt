Sample: convolutionFFT2D
Minimum spec: SM 3.0

This sample demonstrates how 2D convolutions with very large kernel sizes can be efficiently implemented using FFT transformations.

Key concepts:
Image Processing
CUFFT Library
