Sample: scalarProd
Minimum spec: SM 3.0

This sample calculates scalar products of a given set of input vector pairs.

Key concepts:
Linear Algebra
