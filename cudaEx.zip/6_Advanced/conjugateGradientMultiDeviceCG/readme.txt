Sample: conjugateGradientMultiDeviceCG
Minimum spec: SM 6.0

This sample implements a conjugate gradient solver on multiple GPUs using Multi Device Cooperative Groups, also uses Unified Memory optimized using prefetching and usage hints.

Key concepts:
Unified Memory
Linear Algebra
Cooperative Groups
MultiDevice Cooperative Groups
