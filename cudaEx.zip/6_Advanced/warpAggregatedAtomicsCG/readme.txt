Sample: warpAggregatedAtomicsCG
Minimum spec: SM 3.0

This sample demonstrates how using Cooperative Groups (CG) to perform warp aggregated atomics, a useful technique to improve performance when many threads atomically add to a single counter.

Key concepts:
Cooperative Groups
Atomic Intrinsics
