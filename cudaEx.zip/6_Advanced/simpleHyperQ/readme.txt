Sample: simpleHyperQ
Minimum spec: SM 3.0

This sample demonstrates the use of CUDA streams for concurrent execution of several kernels on devices which provide HyperQ (SM 3.5).  Devices without HyperQ (SM 2.0 and SM 3.0) will run a maximum of two kernels concurrently.

Key concepts:
CUDA Systems Integration
Performance Strategies
