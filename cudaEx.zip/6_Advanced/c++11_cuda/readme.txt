Sample: c++11_cuda
Minimum spec: SM 3.0

This sample demonstrates C++11 feature support in CUDA. It scans a input text file and prints no. of occurrences of x, y, z, w characters. 

Key concepts:
CPP11 CUDA
