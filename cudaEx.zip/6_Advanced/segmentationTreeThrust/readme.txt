Sample: segmentationTreeThrust
Minimum spec: SM 3.0

This sample demonstrates an approach to the image segmentation trees construction.  This method is based on Boruvka's MST algorithm.

Key concepts:
Data-Parallel Algorithms
Performance Strategies
